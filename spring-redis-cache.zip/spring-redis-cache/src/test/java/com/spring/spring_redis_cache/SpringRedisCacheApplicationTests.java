package com.spring.spring_redis_cache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRedisCacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
